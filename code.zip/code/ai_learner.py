import numpy as np
import random
import time
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import namedtuple, deque
import itertools
import signal
import getopt
import sys
from rubiks import Cube, face_relations


# ================= GLOBAL CONFIG =====================

cube_edge_length = 2
network_depth = 3
initial_seed = None
use_reinforcement_learning = True

run_seeds = []
solution_records = []

enable_reset_threshold = True
reset_after_iterations = 600000

Experience = namedtuple("Experience", ("state", "action", "next_state", "reward"))

BATCH_SIZE = 4096
GAMMA = 0.95
epsilon_start = 0.975
epsilon_min = 0.03
epsilon_decay = 1_000_000
global_step_count = 0

recent_actions = deque([-1] * 7, maxlen=7)


# ================= SIGNAL HANDLER =====================

def graceful_exit(sig, frame):
    global continue_attempt, continue_main_loop, start_time
    global best_cube_state, best_correct_count

    signal.signal(signal.SIGINT, original_sig)
    pause_time = time.time()

    print("\n\n---- PAUSED ----")

    try:
        if 'best_cube_state' in globals():
            print_best_cube_info(best_cube_state, best_correct_count)
        if len(solution_records) > 0:
            print_solution_records()

        ans = input("Quit? (y/n) > ").lower().strip()
        if ans.startswith("y"):
            continue_main_loop = False
            continue_attempt = False

    except KeyboardInterrupt:
        continue_main_loop = False
        continue_attempt = False

    if continue_main_loop:
        print("\n---- RESUMING ----")
    else:
        print("\n---- QUITTING ----")

    if 'start_time' in globals():
        start_time += time.time() - pause_time
    signal.signal(signal.SIGINT, graceful_exit)


original_sig = signal.getsignal(signal.SIGINT)
signal.signal(signal.SIGINT, graceful_exit)


# ==================== DQN MODEL ======================

class DQN(nn.Module):
    def __init__(self):
        super().__init__()

        total_faces = 6 * cube_edge_length * cube_edge_length
        input_size = total_faces * 6
        num_actions = 6 * 2

        if network_depth == 2:
            self.layers = nn.Sequential(
                nn.Linear(input_size, 2 * num_actions),
                nn.SELU(),
                nn.Linear(2 * num_actions, num_actions)
            )
        elif network_depth == 3:
            self.layers = nn.Sequential(
                nn.Linear(input_size, total_faces),
                nn.SELU(),
                nn.Linear(total_faces, 2 * num_actions),
                nn.SELU(),
                nn.Linear(2 * num_actions, num_actions)
            )
        else:
            self.layers = nn.Sequential(
                nn.Linear(input_size, total_faces),
                nn.SELU(),
                nn.Linear(total_faces, total_faces),
                nn.SELU(),
                nn.Linear(total_faces, 2 * num_actions),
                nn.SELU(),
                nn.Linear(2 * num_actions, num_actions)
            )

    def forward(self, x):
        return self.layers(x)


# ================== REPLAY BUFFER ====================

class ReplayBuffer:
    def __init__(self, cap):
        self.cap = cap
        self.data = []
        self.idx = 0

    def push(self, *args):
        if len(self.data) < self.cap:
            self.data.append(None)
        self.data[self.idx] = Experience(*args)
        self.idx = (self.idx + 1) % self.cap

    def sample(self, batch_size):
        return random.sample(self.data, batch_size)

    def __len__(self):
        return len(self.data)


# =============== ACTION VALIDATION ===================

def is_valid_action(action_id):
    valid = True

    # Prevent opposite move
    if action_id % 2 == 0:
        if recent_actions[-1] == action_id + 1:
            valid = False
    else:
        if recent_actions[-1] == action_id - 1:
            valid = False

    # Prevent 4 identical repeated moves
    last3 = list(itertools.islice(recent_actions, len(recent_actions) - 3, len(recent_actions)))
    if recent_actions[-1] == action_id and len(set(last3)) == 1:
        valid = False

    return valid


# =============== ACTION SELECTION ====================

def choose_action(state_tensor):
    global global_step_count, epsilon_threshold

    epsilon_threshold = (
        epsilon_min +
        (epsilon_start - epsilon_min) * np.exp(-global_step_count / epsilon_decay)
    )

    r = random.random()

    if r > epsilon_threshold:  # exploit
        with torch.no_grad():
            q_vals = q_network(state_tensor)
            ranked = torch.argsort(q_vals, descending=True)

            pos = 0
            action = ranked[pos]
            while not is_valid_action(action):
                pos += 1
                action = ranked[pos]

    else:  # explore
        action = torch.randint(0, 12, (1,), dtype=torch.long)[0]
        while not is_valid_action(action):
            action = torch.randint(0, 12, (1,), dtype=torch.long)[0]

    recent_actions.append(int(action))
    global_step_count += 1
    return action.view(1)


# ================== REWARD CALCULATION ===============

def count_correct_corners(faces):
    correct = 0
    for face_idx in [0, 5]:
        u = face_relations[f"{face_idx}_u"]
        l = face_relations[f"{face_idx}_l"]
        d = face_relations[f"{face_idx}_d"]
        r = face_relations[f"{face_idx}_r"]

        up_face = faces[u]
        left_face = faces[l]
        down_face = faces[d]
        right_face = faces[r]

        if face_idx == 0:
            if faces[0, 0, 0] == 0 and left_face[0, -1] == l and up_face[-1, 0] == u: correct += 1
            if faces[0, 0, -1] == 0 and right_face[0, 0] == r and up_face[-1, -1] == u: correct += 1
            if faces[0, -1, 0] == 0 and left_face[-1, -1] == l and down_face[0, 0] == d: correct += 1
            if faces[0, -1, -1] == 0 and right_face[-1, 0] == r and down_face[0, -1] == d: correct += 1

        else:  # face_idx == 5
            if faces[5, 0, 0] == 5 and left_face[0, -1] == l and up_face[0, -1] == u: correct += 1
            if faces[5, 0, -1] == 5 and right_face[0, 0] == r and up_face[0, 0] == u: correct += 1
            if faces[5, -1, 0] == 5 and left_face[-1, -1] == l and down_face[-1, -1] == d: correct += 1
            if faces[5, -1, -1] == 5 and right_face[-1, 0] == r and down_face[-1, 0] == d: correct += 1

    return correct


def compute_reward(cube):
    total_correct = 0.0
    reward = 0.0

    # corners contribute 3 each
    corners = count_correct_corners(cube.faces)
    total_correct += corners * 3

    # per-face color correctness
    for face_idx, face in enumerate(cube.faces):
        match = np.sum(face.flatten() == face_idx)
        reward += 2 * match / (cube.edge_length ** 2)

    reward += total_correct
    return total_correct, reward


# ==================== TRAIN STEP ======================

def train_step():
    if len(replay_buffer) < BATCH_SIZE:
        return

    batch = replay_buffer.sample(BATCH_SIZE)
    batch = Experience(*zip(*batch))

    state_batch = torch.cat(batch.state).reshape(-1, 6 * 6 * cube_edge_length * cube_edge_length)
    next_state_batch = torch.cat(batch.next_state).reshape(-1, 6 * 6 * cube_edge_length * cube_edge_length)
    action_batch = torch.cat(batch.action)
    reward_batch = torch.cat(batch.reward)

    q_pred = q_network(state_batch).gather(1, action_batch.unsqueeze(1))
    max_next_q = q_network(next_state_batch).max(1)[0].detach()
    target_q = reward_batch + GAMMA * max_next_q

    loss = F.smooth_l1_loss(q_pred, target_q.unsqueeze(1))

    optimizer.zero_grad()
    loss.backward()

    for param in q_network.parameters():
        param.grad.data.clamp_(-6, 6)

    optimizer.step()


# ================== PRINTING UTILS ====================

def print_solution_records():
    print("\nSolved cubes:")
    for idx, rec in enumerate(solution_records):
        print(f"{idx}: Attempt={rec[0]}, Rotations={rec[1]}, Time={int(rec[2])}, Seed={rec[3]}")
    print()


def print_best_cube_info(cube, correct):
    print(f"\nBest cube ({correct} correct pieces):")
    print(cube)


# ===================== ATTEMPT LOOP ===================

def run_attempt():
    global attempt_index, start_time, best_cube_state
    global best_correct_count, iteration_count, continue_attempt

    continue_attempt = True

    cube = Cube(edge_length=cube_edge_length)
    print("\nOriginal cube:")
    print(cube)

    print("\nScrambling...")
    cube.scramble()

    total_squares = 6 * cube.edge_length * cube.edge_length
    total_state_size = total_squares * 6

    iteration_count = 0
    best_correct_count = 0
    best_cube_state = cube.copy()
    best_reward = 0
    start_time = time.time()

    stats_window = 1000
    rolling_correct = [0] * stats_window
    rolling_reward = [0] * stats_window


    # initial state
    if use_reinforcement_learning:
        state_index_grid = torch.arange(0, total_state_size, 6, dtype=torch.int64)
        flat_faces = torch.as_tensor(cube.faces.flatten(), dtype=torch.int64)
        state_tensor = torch.zeros([total_state_size], dtype=torch.float32)
        state_tensor[state_index_grid + flat_faces] = 1

    while continue_attempt:

        # step
        if use_reinforcement_learning:
            action = choose_action(state_tensor)
            cube.rotate(int(action))
        else:
            cube.random_rotation()

        # reward
        correct_now, reward_now = compute_reward(cube)
        rolling_correct[iteration_count % stats_window] = correct_now
        rolling_reward[iteration_count % stats_window] = reward_now

        if correct_now > best_correct_count:
            best_correct_count = correct_now
            best_cube_state = cube.copy()

        if correct_now == total_squares:
            print("\nSOLVED!")
            solution_records.append([
                attempt_index, iteration_count,
                time.time() - start_time, run_seeds[-1]
            ])
            break

        if reward_now > best_reward:
            best_reward = reward_now

        # RL update
        if use_reinforcement_learning:
            flat_faces = torch.as_tensor(cube.faces.flatten(), dtype=torch.int64)
            next_state = torch.zeros([total_state_size], dtype=torch.float32)
            next_state[state_index_grid + flat_faces] = 1

            replay_buffer.push(state_tensor, action, next_state, torch.as_tensor([reward_now]))

            state_tensor = next_state

            if global_step_count % BATCH_SIZE == 0:
                train_step()

        iteration_count += 1

    print_best_cube_info(best_cube_state, best_correct_count)


# ===================== MAIN LOOP =====================

def main():
    global cube_edge_length, network_depth, initial_seed
    global use_reinforcement_learning, replay_buffer
    global q_network, optimizer
    global continue_main_loop, attempt_index

    continue_main_loop = True
    attempt_index = 0

    # Parse arguments
    try:
        opts, args = getopt.getopt(
            sys.argv[1:], "s:l:h",
            ["size=", "layers=", "seed=", "random", "help"]
        )

        for opt, arg in opts:
            if opt in ("-h", "--help"):
                print("Help:")
                print(" -s, --size=N       cube size (default 2)")
                print(" -l, --layers=N     NN layers (2, 3, 4)")
                print(" --seed=N           RNG seed")
                print(" --random           no RL, random moves only")
                quit()

            elif opt in ("-s", "--size"):
                cube_edge_length = max(2, int(arg))

            elif opt in ("-l", "--layers"):
                n = int(arg)
                if n in (2, 3, 4):
                    network_depth = n

            elif opt == "--seed":
                initial_seed = int(arg)

            elif opt == "--random":
                use_reinforcement_learning = False

    except:
        print("Invalid arguments. Use --help.")
        quit()

    # Init model + buffer
    q_network = DQN()
    optimizer = optim.RMSprop(q_network.parameters())
    replay_buffer = ReplayBuffer(15000)

    # Main run loop
    last_state = random.getstate()

    while continue_main_loop:

        if attempt_index == 0 and initial_seed is not None:
            seed = initial_seed
            random.seed(initial_seed)
        else:
            random.setstate(last_state)
            random.seed(random.randint(0, 2**30))
            seed = random.randint(0, 2**30)

        last_state = random.getstate()
        run_seeds.append(seed)
        torch.manual_seed(seed)

        run_attempt()
        attempt_index += 1


if __name__ == "__main__":
    main()
